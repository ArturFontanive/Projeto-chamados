<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

$u = exigir_login('cliente'); // só o cliente registra chamado

$erros     = [];
$titulo    = '';
$descricao = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo    = trim((string) ($_POST['titulo'] ?? ''));
    $descricao = trim((string) ($_POST['descricao'] ?? ''));

    if (!csrf_ok()) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    }
    if (mb_strlen($titulo) < 5 || mb_strlen($titulo) > 150) {
        $erros[] = 'O título deve ter entre 5 e 150 caracteres.';
    }
    if (mb_strlen($descricao) < 10 || mb_strlen($descricao) > 5000) {
        $erros[] = 'A descrição deve ter entre 10 e 5000 caracteres.';
    }

    if (!$erros) {
        try {
            $pdo  = db();
            $stmt = $pdo->prepare('INSERT INTO chamados (cliente_id, titulo, descricao) VALUES (:c, :t, :d)');
            $stmt->execute([':c' => $u['id'], ':t' => $titulo, ':d' => $descricao]);

            flash('Chamado #' . $pdo->lastInsertId() . ' registrado!');
            header('Location: chamados.php');
            exit;
        } catch (PDOException $ex) {
            error_log('Erro ao registrar chamado: ' . $ex->getMessage());
            $erros[] = 'Erro ao salvar o chamado. Tente novamente.';
        }
    }
}

topo('Novo chamado', $u);
?>
<main class="conteudo">
    <section class="cartao">
        <h1>Registrar chamado</h1>
        <?php alertas(null, $erros); ?>
        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">

            <label for="titulo">Título</label>
            <input type="text" id="titulo" name="titulo" maxlength="150" required value="<?= e($titulo) ?>">

            <label for="descricao">Descrição do problema</label>
            <textarea id="descricao" name="descricao" rows="6" maxlength="5000" required><?= e($descricao) ?></textarea>

            <button type="submit">Enviar chamado</button>
        </form>
    </section>
</main>
<?php rodape();
