<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

if (usuario_logado() !== null) {
    header('Location: chamados.php');
    exit;
}

$erros = [];
$nome  = '';
$email = '';

// O cadastro público cria SEMPRE um cliente. O adm já vem criado pelo banco.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome      = trim((string) ($_POST['nome'] ?? ''));
    $email     = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
    $senha     = (string) ($_POST['senha'] ?? '');
    $confirmar = (string) ($_POST['confirmar'] ?? '');

    if (!csrf_ok()) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    }
    if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) {
        $erros[] = 'Informe o nome (3 a 120 caracteres).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($senha) < 8) {
        $erros[] = 'A senha deve ter pelo menos 8 caracteres.';
    }
    if ($senha !== $confirmar) {
        $erros[] = 'A confirmação de senha não confere.';
    }

    if (!$erros) {
        try {
            $stmt = db()->prepare(
                "INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES (:n, :e, :s, 'cliente')"
            );
            $stmt->execute([':n' => $nome, ':e' => $email, ':s' => password_hash($senha, PASSWORD_DEFAULT)]);

            flash('Cadastro realizado! Faça login para continuar.');
            header('Location: login.php');
            exit;
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') {
                $erros[] = 'Este e-mail já está cadastrado.';
            } else {
                error_log('Erro no cadastro: ' . $ex->getMessage());
                $erros[] = 'Erro ao salvar o cadastro. Tente novamente.';
            }
        }
    }
}

topo('Cadastro', null);
?>
<section class="cartao">
    <h1>Criar conta</h1>
    <?php alertas(null, $erros); ?>
    <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">

        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" maxlength="120" required value="<?= e($nome) ?>">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" maxlength="160" required value="<?= e($email) ?>">

        <label for="senha">Senha (mínimo 8 caracteres)</label>
        <input type="password" id="senha" name="senha" minlength="8" required>

        <label for="confirmar">Confirmar senha</label>
        <input type="password" id="confirmar" name="confirmar" minlength="8" required>

        <button type="submit">Cadastrar</button>
        <p class="rodape-form">Já tem conta? <a href="login.php">Entrar</a></p>
    </form>
</section>
<?php rodape();
