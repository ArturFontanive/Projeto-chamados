<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

$u   = exigir_login();
$ok  = flash();
$adm = $u['perfil'] === 'adm';

$sql = 'SELECT c.id, c.titulo, c.status, c.criado_em, cli.nome AS cliente
          FROM chamados c
          JOIN usuarios cli ON cli.id = c.cliente_id';
$params = [];
$ver = 'todos';

if ($adm) {
    $ver = ($_GET['ver'] ?? '') === 'abertos' ? 'abertos' : 'todos';
    if ($ver === 'abertos') {
        $sql .= " WHERE c.status = 'aberto'";
    }
} else {
    $sql .= ' WHERE c.cliente_id = :uid';
    $params[':uid'] = $u['id'];
}

$stmt = db()->prepare($sql . ' ORDER BY c.criado_em DESC LIMIT 200');
$stmt->execute($params);
$chamados = $stmt->fetchAll();

$titulo = $adm ? 'Gerenciar chamados' : 'Meus chamados';
topo($titulo, $u);
?>
<main class="conteudo">
    <section class="cartao">
        <h1><?= e($titulo) ?></h1>
        <?php alertas($ok); ?>

        <?php if ($adm): ?>
            <nav class="abas">
                <a href="chamados.php?ver=abertos" class="<?= $ver === 'abertos' ? 'ativa' : '' ?>">Abertos</a>
                <a href="chamados.php" class="<?= $ver === 'todos' ? 'ativa' : '' ?>">Todos</a>
            </nav>
        <?php endif; ?>

        <?php if (!$chamados): ?>
            <p class="vazio">Nenhum chamado encontrado.
                <?php if (!$adm): ?><a href="novo_chamado.php">Registrar um chamado</a><?php endif; ?>
            </p>
        <?php else: ?>
            <div class="tabela-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Título</th>
                            <?php if ($adm): ?><th>Cliente</th><?php endif; ?>
                            <th>Status</th>
                            <th>Aberto em</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($chamados as $c): ?>
                        <tr>
                            <td><?= (int) $c['id'] ?></td>
                            <td><a href="ver_chamado.php?id=<?= (int) $c['id'] ?>"><?= e($c['titulo']) ?></a></td>
                            <?php if ($adm): ?><td><?= e($c['cliente']) ?></td><?php endif; ?>
                            <td><span class="status status-<?= e($c['status']) ?>"><?= $c['status'] === 'aberto' ? 'Aberto' : 'Fechado' ?></span></td>
                            <td><?= e(data_br($c['criado_em'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
<?php rodape();
