<?php
declare(strict_types=1);

require_once __DIR__ . '/conexao.php';

session_name('chamados_simples'); // evita misturar com sessões de outros sistemas no localhost
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function e(?string $v): string
{
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

function data_br(?string $d): string
{
    return $d ? date('d/m/Y H:i', strtotime($d)) : '—';
}

function csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_ok(): bool
{
    return hash_equals($_SESSION['csrf'] ?? '', (string) ($_POST['csrf'] ?? ''));
}

function flash(?string $msg = null): ?string
{
    if ($msg !== null) {
        $_SESSION['flash'] = $msg;
        return null;
    }
    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}

/** Devolve o usuário da sessão ou null se não houver login válido. */
function usuario_logado(): ?array
{
    $u = $_SESSION['usuario'] ?? null;
    if (!is_array($u) || !isset($u['id'], $u['nome'], $u['perfil'])) {
        return null;
    }
    return $u;
}

function exigir_login(?string $perfil = null): array
{
    $u = usuario_logado();
    if ($u === null) {
        unset($_SESSION['usuario']); // sessão antiga ou inválida
        header('Location: login.php');
        exit;
    }
    if ($perfil !== null && $u['perfil'] !== $perfil) {
        http_response_code(403);
        exit('Acesso negado.');
    }
    return $u;
}

function topo(string $titulo, ?array $u): void
{
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($titulo) ?> · Chamados</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topo">
    <a class="marca" href="chamados.php">Chamados</a>
    <nav>
        <?php if ($u): ?>
            <a href="chamados.php"><?= $u['perfil'] === 'adm' ? 'Gerenciar' : 'Meus chamados' ?></a>
            <?php if ($u['perfil'] === 'cliente'): ?><a href="novo_chamado.php">Novo chamado</a><?php endif; ?>
            <span class="nome"><?= e($u['nome']) ?></span>
            <a href="logout.php">Sair</a>
        <?php else: ?>
            <a href="login.php">Entrar</a>
            <a href="cadastro.php">Cadastrar</a>
        <?php endif; ?>
    </nav>
</header>
<?php
}

function rodape(): void
{
    echo "</body>\n</html>\n";
}

function alertas(?string $ok, array $erros = []): void
{
    if ($ok) {
        echo '<div class="alerta sucesso">' . e($ok) . '</div>';
    }
    if ($erros) {
        echo '<div class="alerta erro"><ul>';
        foreach ($erros as $x) {
            echo '<li>' . e($x) . '</li>';
        }
        echo '</ul></div>';
    }
}
