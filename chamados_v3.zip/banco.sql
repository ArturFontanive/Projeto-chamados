-- OPCIONAL: o sistema já cria o banco e as tabelas sozinho ao abrir pela primeira vez.
-- Use este script só se preferir criar tudo pelo DBeaver (Alt + X).
CREATE DATABASE IF NOT EXISTS chamados_simples
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE chamados_simples;

CREATE TABLE IF NOT EXISTS usuarios (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome       VARCHAR(120) NOT NULL,
    email      VARCHAR(160) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    perfil     ENUM('cliente','adm') NOT NULL DEFAULT 'cliente',
    PRIMARY KEY (id),
    UNIQUE KEY uk_usuarios_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS chamados (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    cliente_id INT UNSIGNED NOT NULL,
    titulo     VARCHAR(150) NOT NULL,
    descricao  TEXT         NOT NULL,
    status     ENUM('aberto','fechado') NOT NULL DEFAULT 'aberto',
    criado_em  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fechado_em TIMESTAMP    NULL DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_chamados_cliente (cliente_id),
    KEY idx_chamados_status (status),
    CONSTRAINT fk_chamados_cliente FOREIGN KEY (cliente_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

-- Adm inicial: adm@chamados.local / admin123 (troque depois)
INSERT IGNORE INTO usuarios (nome, email, senha_hash, perfil) VALUES
    ('Administrador', 'adm@chamados.local', '$2y$10$Xfv7O7L9UWaAgCBQ49gC0eVP.rVv6zTFCyCYf81yd4DOa5efXr6rm', 'adm');

SELECT id, nome, email, perfil FROM usuarios;
