<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

header('Location: ' . (usuario_logado() !== null ? 'chamados.php' : 'login.php'));
exit;
