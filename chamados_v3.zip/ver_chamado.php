<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

$u   = exigir_login();
$adm = $u['perfil'] === 'adm';
$pdo = db();
$id  = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT) ?: 0;

/** @return array|false */
function buscar(PDO $pdo, int $id)
{
    $stmt = $pdo->prepare(
        'SELECT c.id, c.cliente_id, c.titulo, c.descricao, c.status, c.criado_em, c.fechado_em,
                cli.nome AS cliente
           FROM chamados c
           JOIN usuarios cli ON cli.id = c.cliente_id
          WHERE c.id = :id LIMIT 1'
    );
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

$chamado = buscar($pdo, $id);

// Cliente só enxerga os próprios chamados.
$naoEncontrado = !$chamado || (!$adm && (int) $chamado['cliente_id'] !== $u['id']);
if ($naoEncontrado) {
    http_response_code(404);
}

$erros = [];

// Só o adm fecha, e só se estiver aberto.
if (!$naoEncontrado && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$adm || ($_POST['acao'] ?? '') !== 'fechar') {
        $erros[] = 'Ação inválida.';
    } elseif (!csrf_ok()) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    } else {
        $upd = $pdo->prepare("UPDATE chamados SET status = 'fechado', fechado_em = NOW() WHERE id = :id AND status = 'aberto'");
        $upd->execute([':id' => $id]);

        if ($upd->rowCount() === 1) {
            flash('Chamado #' . $id . ' fechado.');
            header('Location: chamados.php?ver=abertos');
            exit;
        }
        $erros[] = 'Este chamado já estava fechado.';
        $chamado = buscar($pdo, $id);
    }
}

topo($naoEncontrado ? 'Chamado não encontrado' : 'Chamado #' . $chamado['id'], $u);
?>
<main class="conteudo">
    <section class="cartao">
        <a class="voltar" href="chamados.php">&larr; Voltar à lista</a>

        <?php if ($naoEncontrado): ?>
            <h1>Chamado não encontrado</h1>
            <p>Esse chamado não existe ou você não tem acesso a ele.</p>
        <?php else: ?>
            <?php alertas(null, $erros); ?>

            <h1>#<?= (int) $chamado['id'] ?> · <?= e($chamado['titulo']) ?></h1>

            <dl class="detalhes">
                <div><dt>Cliente</dt><dd><?= e($chamado['cliente']) ?></dd></div>
                <div><dt>Status</dt><dd><span class="status status-<?= e($chamado['status']) ?>"><?= $chamado['status'] === 'aberto' ? 'Aberto' : 'Fechado' ?></span></dd></div>
                <div><dt>Aberto em</dt><dd><?= e(data_br($chamado['criado_em'])) ?></dd></div>
                <div><dt>Fechado em</dt><dd><?= e(data_br($chamado['fechado_em'])) ?></dd></div>
            </dl>

            <h2>Descrição</h2>
            <p class="texto-livre"><?= nl2br(e($chamado['descricao'])) ?></p>

            <?php if ($adm && $chamado['status'] === 'aberto'): ?>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
                    <input type="hidden" name="acao" value="fechar">
                    <button type="submit">Fechar chamado</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</main>
<?php rodape();
