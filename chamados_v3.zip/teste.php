<?php
declare(strict_types=1);
// Página de diagnóstico: abra /chamados/teste.php e veja qual passo falha.
// Apague este arquivo depois que tudo estiver funcionando.
require_once __DIR__ . '/conexao.php';

header('Content-Type: text/html; charset=utf-8');

function passo(string $nome, bool $ok, string $detalhe = ''): void
{
    echo ($ok ? '✔ ' : '✘ ') . htmlspecialchars($nome, ENT_QUOTES, 'UTF-8');
    if ($detalhe !== '') {
        echo ' — ' . htmlspecialchars($detalhe, ENT_QUOTES, 'UTF-8');
    }
    echo "\n";
}

echo '<pre style="font:16px/1.7 Consolas,monospace">';
echo "DIAGNÓSTICO\n\n";

passo('Versão do PHP', version_compare(PHP_VERSION, '7.4', '>='), PHP_VERSION . ' (precisa de 7.4 ou mais)');

$temPdo = extension_loaded('pdo_mysql');
passo('Extensão pdo_mysql ligada', $temPdo, $temPdo ? '' : 'ative extension=pdo_mysql no php.ini do XAMPP e reinicie o Apache');

if ($temPdo) {
    $pdo = null;
    try {
        $pdo = new PDO(sprintf('mysql:host=%s;port=%d;charset=utf8mb4', DB_HOST, DB_PORT), DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        passo('Conectou ao MySQL', true, DB_HOST . ':' . DB_PORT . ' com o usuário ' . DB_USER);
    } catch (PDOException $e) {
        passo('Conectou ao MySQL', false, $e->getMessage());
        echo "\nDicas: o MySQL está ligado no painel do XAMPP? A porta (DB_PORT) e a senha (DB_PASS) em conexao.php estão certas?\n";
    }

    if ($pdo) {
        try {
            $existe = $pdo->query("SHOW DATABASES LIKE '" . DB_NAME . "'")->fetchColumn();
            passo('Banco ' . DB_NAME . ' existe', (bool) $existe, $existe ? '' : 'será criado sozinho ao abrir o sistema');
            if ($existe) {
                $pdo->exec('USE `' . DB_NAME . '`');
                $t1 = (bool) $pdo->query("SHOW TABLES LIKE 'usuarios'")->fetchColumn();
                $t2 = (bool) $pdo->query("SHOW TABLES LIKE 'chamados'")->fetchColumn();
                passo('Tabelas usuarios e chamados', $t1 && $t2, $t1 && $t2 ? '' : 'serão criadas sozinhas ao abrir o sistema');
                if ($t1) {
                    $n = (int) $pdo->query("SELECT COUNT(*) FROM usuarios WHERE perfil = 'adm'")->fetchColumn();
                    passo('Usuário adm existe', $n > 0, $n > 0 ? '' : 'será criado sozinho ao abrir o sistema');
                }
            }
        } catch (PDOException $e) {
            passo('Consulta ao banco', false, $e->getMessage());
        }
    }
}

echo "\nSe tudo estiver ✔, abra login.php (adm@chamados.local / admin123).\n";
echo '</pre>';
