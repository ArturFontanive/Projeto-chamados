<?php
declare(strict_types=1);

// ---------- Configuração (já vem no padrão do XAMPP) ----------
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;          // se o MySQL do XAMPP usa outra porta, troque aqui
const DB_NAME = 'chamados_simples';
const DB_USER = 'root';
const DB_PASS = '';            // XAMPP: root sem senha

// true = mostra o motivo real quando não conecta (troque para false em produção)
const MOSTRAR_ERRO = true;

/**
 * Conecta ao MySQL. Na primeira vez cria sozinho o banco, as tabelas
 * e o usuário adm: não precisa rodar nada no DBeaver.
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $opcoes = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $dsnServidor = sprintf('mysql:host=%s;port=%d;charset=utf8mb4', DB_HOST, DB_PORT);
    $dsnBanco    = $dsnServidor . ';dbname=' . DB_NAME;

    try {
        try {
            $pdo = new PDO($dsnBanco, DB_USER, DB_PASS, $opcoes);
        } catch (PDOException $e) {
            // 1049 = o banco ainda não existe: cria e conecta de novo
            if ((int) $e->getCode() !== 1049 && stripos($e->getMessage(), 'Unknown database') === false) {
                throw $e;
            }
            $servidor = new PDO($dsnServidor, DB_USER, DB_PASS, $opcoes);
            $servidor->exec(
                'CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
            );
            $pdo = new PDO($dsnBanco, DB_USER, DB_PASS, $opcoes);
        }

        preparar_banco($pdo);
    } catch (PDOException $e) {
        error_log('Erro de banco: ' . $e->getMessage());
        http_response_code(500);
        exit(
            'Não foi possível conectar ao banco de dados.'
            . (MOSTRAR_ERRO ? ' Motivo: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') : '')
        );
    }

    return $pdo;
}

/** Cria tabelas e o adm inicial, se ainda não existirem. */
function preparar_banco(PDO $pdo): void
{
    $temSessao = session_status() === PHP_SESSION_ACTIVE;
    if ($temSessao && !empty($_SESSION['db_pronto'])) {
        return;
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS usuarios (
            id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nome       VARCHAR(120) NOT NULL,
            email      VARCHAR(160) NOT NULL,
            senha_hash VARCHAR(255) NOT NULL,
            perfil     ENUM('cliente','adm') NOT NULL DEFAULT 'cliente',
            PRIMARY KEY (id),
            UNIQUE KEY uk_usuarios_email (email)
        ) ENGINE=InnoDB"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS chamados (
            id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
            cliente_id INT UNSIGNED NOT NULL,
            titulo     VARCHAR(150) NOT NULL,
            descricao  TEXT         NOT NULL,
            status     ENUM('aberto','fechado') NOT NULL DEFAULT 'aberto',
            criado_em  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
            fechado_em TIMESTAMP    NULL DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_chamados_cliente (cliente_id),
            KEY idx_chamados_status (status),
            CONSTRAINT fk_chamados_cliente FOREIGN KEY (cliente_id) REFERENCES usuarios (id)
        ) ENGINE=InnoDB"
    );

    $temAdm = (int) $pdo->query("SELECT COUNT(*) FROM usuarios WHERE perfil = 'adm'")->fetchColumn();
    if ($temAdm === 0) {
        $ins = $pdo->prepare(
            "INSERT IGNORE INTO usuarios (nome, email, senha_hash, perfil) VALUES (:n, :e, :s, 'adm')"
        );
        $ins->execute([
            ':n' => 'Administrador',
            ':e' => 'adm@chamados.local',
            ':s' => password_hash('admin123', PASSWORD_DEFAULT),
        ]);
    }

    if ($temSessao) {
        $_SESSION['db_pronto'] = true;
    }
}
