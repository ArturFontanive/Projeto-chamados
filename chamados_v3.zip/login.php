<?php
declare(strict_types=1);

require_once __DIR__ . '/funcoes.php';

if (usuario_logado() !== null) {
    header('Location: chamados.php');
    exit;
}

$ok    = flash();
$erros = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
    $senha = (string) ($_POST['senha'] ?? '');

    if (!csrf_ok()) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    } else {
        $stmt = db()->prepare('SELECT id, nome, senha_hash, perfil FROM usuarios WHERE email = :e LIMIT 1');
        $stmt->execute([':e' => $email]);
        $u = $stmt->fetch();

        if ($u && password_verify($senha, $u['senha_hash'])) {
            session_regenerate_id(true);
            $_SESSION['usuario'] = ['id' => (int) $u['id'], 'nome' => $u['nome'], 'perfil' => $u['perfil']];
            header('Location: chamados.php');
            exit;
        }
        $erros[] = 'E-mail ou senha inválidos.';
    }
}

topo('Entrar', null);
?>
<section class="cartao">
    <h1>Entrar</h1>
    <?php alertas($ok, $erros); ?>
    <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" required value="<?= e($email) ?>">

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required>

        <button type="submit">Entrar</button>
        <p class="rodape-form">Não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
    </form>
</section>
<?php rodape();
