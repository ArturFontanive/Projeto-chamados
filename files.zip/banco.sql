-- ==========================================================
-- Sistema de Chamados · Concessionária  (versão 2 — com painel admin)
--
-- BANCO NOVO (primeira instalação):
--   Rode este script inteiro no DBeaver: abra em SQL Editor
--   e execute com Alt + X (Execute SQL Script).
--
-- JÁ RODOU A VERSÃO ANTIGA?
--   Não use este arquivo. Rode o "migracao_v2.sql", que só
--   acrescenta o que falta e preserva seus dados.
-- ==========================================================

CREATE DATABASE IF NOT EXISTS chamados_concessionaria
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE chamados_concessionaria;

-- ---------- Setores ----------
CREATE TABLE IF NOT EXISTS setores (
    id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(80)  NOT NULL,
    ativo TINYINT(1)  NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uk_setores_nome (nome)
) ENGINE=InnoDB;

-- ---------- Usuários ----------
CREATE TABLE IF NOT EXISTS usuarios (
    id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome               VARCHAR(120) NOT NULL,
    email              VARCHAR(160) NOT NULL,
    senha_hash         VARCHAR(255) NOT NULL,
    setor_id           INT UNSIGNED NOT NULL,
    perfil             ENUM('solicitante','tecnico','admin') NOT NULL DEFAULT 'solicitante',
    ativo              TINYINT(1)   NOT NULL DEFAULT 1,
    forcar_troca_senha TINYINT(1)   NOT NULL DEFAULT 0,
    ultimo_login       TIMESTAMP    NULL DEFAULT NULL,
    criado_em          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_usuarios_email (email),
    KEY idx_usuarios_perfil (perfil),
    CONSTRAINT fk_usuarios_setor FOREIGN KEY (setor_id) REFERENCES setores (id)
) ENGINE=InnoDB;

-- ---------- Chamados ----------
CREATE TABLE IF NOT EXISTS chamados (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id    INT UNSIGNED NOT NULL,
    atribuido_id  INT UNSIGNED NULL DEFAULT NULL,
    titulo        VARCHAR(150) NOT NULL,
    descricao     TEXT         NOT NULL,
    prioridade    ENUM('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
    status        ENUM('aberto','em_andamento','resolvido','fechado') NOT NULL DEFAULT 'aberto',
    criado_em     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_chamados_usuario (usuario_id),
    KEY idx_chamados_atribuido (atribuido_id),
    KEY idx_chamados_status (status),
    CONSTRAINT fk_chamados_usuario  FOREIGN KEY (usuario_id)   REFERENCES usuarios (id),
    CONSTRAINT fk_chamados_atribuido FOREIGN KEY (atribuido_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Comentários ----------
CREATE TABLE IF NOT EXISTS comentarios (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    chamado_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    mensagem   TEXT         NOT NULL,
    tipo       ENUM('comentario','sistema') NOT NULL DEFAULT 'comentario',
    criado_em  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_comentarios_chamado (chamado_id),
    CONSTRAINT fk_comentarios_chamado FOREIGN KEY (chamado_id) REFERENCES chamados (id) ON DELETE CASCADE,
    CONSTRAINT fk_comentarios_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

-- ---------- Tentativas de login (bloqueio contra força bruta) ----------
CREATE TABLE IF NOT EXISTS tentativas_login (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email     VARCHAR(160) NOT NULL,
    ip        VARCHAR(45)  NOT NULL,
    criado_em TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tentativas_busca (email, ip, criado_em)
) ENGINE=InnoDB;

-- ---------- Setores iniciais ----------
INSERT IGNORE INTO setores (nome) VALUES
    ('Vendas'), ('Pós-vendas'), ('Oficina'), ('Peças'),
    ('Financeiro'), ('Administrativo'), ('TI');

-- ---------- Administrador inicial ----------
-- E-mail: admin@concessionaria.local
-- Senha provisória: Admin@2026
-- O sistema OBRIGA a trocar a senha no primeiro acesso.
INSERT IGNORE INTO usuarios (nome, email, senha_hash, setor_id, perfil, forcar_troca_senha)
SELECT 'Administrador', 'admin@concessionaria.local',
       '$2y$10$c3DaqRwpyq5VYfP4wQLN6eBsFAVw/dzZIHc3Mmfm4e5.npVQPFM1G',
       s.id, 'admin', 1
  FROM setores s
 WHERE s.nome = 'TI';

-- ---------- Usuário do banco usado pela aplicação ----------
-- IMPORTANTE: troque a senha abaixo antes de rodar,
-- e use a MESMA senha em includes/conexao.php (constante DB_PASS).
CREATE USER IF NOT EXISTS 'app_chamados'@'localhost' IDENTIFIED BY 'TROQUE_ESTA_SENHA';
GRANT SELECT, INSERT, UPDATE, DELETE ON chamados_concessionaria.* TO 'app_chamados'@'localhost';
FLUSH PRIVILEGES;

-- ---------- Conferência rápida ----------
SHOW TABLES;
SELECT id, nome, email, perfil FROM usuarios;
