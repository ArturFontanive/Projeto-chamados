-- ==========================================================
-- MIGRAÇÃO v1 -> v2  (para quem JÁ rodou o banco.sql antigo)
-- Preserva usuários, chamados e comentários existentes.
-- Rode UMA ÚNICA VEZ (Alt + X no DBeaver).
-- ==========================================================

USE chamados_concessionaria;

-- Setores podem ser desativados pelo admin
ALTER TABLE setores
    ADD COLUMN ativo TINYINT(1) NOT NULL DEFAULT 1;

-- Controle de senha e último acesso
ALTER TABLE usuarios
    ADD COLUMN forcar_troca_senha TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN ultimo_login TIMESTAMP NULL DEFAULT NULL,
    ADD KEY idx_usuarios_perfil (perfil);

-- Responsável pelo chamado
ALTER TABLE chamados
    ADD COLUMN atribuido_id INT UNSIGNED NULL DEFAULT NULL AFTER usuario_id,
    ADD KEY idx_chamados_atribuido (atribuido_id),
    ADD CONSTRAINT fk_chamados_atribuido FOREIGN KEY (atribuido_id) REFERENCES usuarios (id) ON DELETE SET NULL;

-- Histórico automático (mudanças de status/responsável) dentro dos comentários
ALTER TABLE comentarios
    ADD COLUMN tipo ENUM('comentario','sistema') NOT NULL DEFAULT 'comentario' AFTER mensagem;

-- Bloqueio contra tentativas de login em excesso
CREATE TABLE IF NOT EXISTS tentativas_login (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email     VARCHAR(160) NOT NULL,
    ip        VARCHAR(45)  NOT NULL,
    criado_em TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tentativas_busca (email, ip, criado_em)
) ENGINE=InnoDB;

-- ---------- Administrador ----------
-- Opção A: criar o admin padrão (senha provisória Admin@2026, troca obrigatória)
INSERT IGNORE INTO usuarios (nome, email, senha_hash, setor_id, perfil, forcar_troca_senha)
SELECT 'Administrador', 'admin@concessionaria.local',
       '$2y$10$c3DaqRwpyq5VYfP4wQLN6eBsFAVw/dzZIHc3Mmfm4e5.npVQPFM1G',
       s.id, 'admin', 1
  FROM setores s
 WHERE s.nome = 'TI';

-- Opção B: promover uma conta que você já tem (troque o e-mail e tire o "--"):
-- UPDATE usuarios SET perfil = 'admin' WHERE email = 'seu@email.com';

SELECT id, nome, email, perfil FROM usuarios;
