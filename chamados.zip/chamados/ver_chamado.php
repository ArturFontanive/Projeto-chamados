<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

const STATUS_VALIDOS = ['aberto', 'em_andamento', 'resolvido', 'fechado'];

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

function rotulo(string $valor): string
{
    static $mapa = ['media' => 'Média', 'em_andamento' => 'Em andamento', 'tecnico' => 'Técnico'];
    return $mapa[$valor] ?? ucfirst($valor);
}

$usuario = $_SESSION['usuario'] ?? null;
if ($usuario === null) {
    header('Location: login.php');
    exit;
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$veTodos = in_array($usuario['perfil'], ['tecnico', 'admin'], true);
$pdo     = db();
$id      = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT) ?: 0;

$stmt = $pdo->prepare(
    'SELECT c.id, c.usuario_id, c.titulo, c.descricao, c.prioridade, c.status,
            c.criado_em, c.atualizado_em, u.nome AS solicitante, s.nome AS setor
       FROM chamados c
       JOIN usuarios u ON u.id = c.usuario_id
       JOIN setores  s ON s.id = u.setor_id
      WHERE c.id = :id
      LIMIT 1'
);
$stmt->execute([':id' => $id]);
$chamado = $stmt->fetch();

// Mesma resposta para "não existe" e "não é seu": não revela a existência de outros chamados.
$naoEncontrado = !$chamado || (!$veTodos && (int) $chamado['usuario_id'] !== (int) $usuario['id']);
if ($naoEncontrado) {
    http_response_code(404);
}

$erros            = [];
$mensagemDigitada = '';

if (!$naoEncontrado && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    } else {
        $acao = (string) ($_POST['acao'] ?? '');

        if ($acao === 'comentar') {
            $mensagemDigitada = trim((string) ($_POST['mensagem'] ?? ''));

            if ($chamado['status'] === 'fechado') {
                $erros[] = 'Chamado fechado não aceita novos comentários.';
            } elseif (mb_strlen($mensagemDigitada) < 2 || mb_strlen($mensagemDigitada) > 2000) {
                $erros[] = 'O comentário deve ter entre 2 e 2000 caracteres.';
            } else {
                $ins = $pdo->prepare(
                    'INSERT INTO comentarios (chamado_id, usuario_id, mensagem)
                     VALUES (:chamado, :usuario, :mensagem)'
                );
                $ins->execute([
                    ':chamado'  => $id,
                    ':usuario'  => (int) $usuario['id'],
                    ':mensagem' => $mensagemDigitada,
                ]);
                $_SESSION['flash'] = ['tipo' => 'sucesso', 'mensagem' => 'Comentário adicionado.'];
                header('Location: ver_chamado.php?id=' . $id);
                exit;
            }
        } elseif ($acao === 'status' && $veTodos) {
            $novoStatus = (string) ($_POST['status'] ?? '');

            if (!in_array($novoStatus, STATUS_VALIDOS, true)) {
                $erros[] = 'Status inválido.';
            } else {
                $upd = $pdo->prepare('UPDATE chamados SET status = :status WHERE id = :id');
                $upd->execute([':status' => $novoStatus, ':id' => $id]);
                $_SESSION['flash'] = ['tipo' => 'sucesso', 'mensagem' => 'Status atualizado para "' . rotulo($novoStatus) . '".'];
                header('Location: ver_chamado.php?id=' . $id);
                exit;
            }
        } else {
            $erros[] = 'Ação inválida.';
        }
    }
}

$comentarios = [];
if (!$naoEncontrado) {
    $stmt = $pdo->prepare(
        'SELECT m.mensagem, m.criado_em, u.nome, u.perfil
           FROM comentarios m
           JOIN usuarios u ON u.id = m.usuario_id
          WHERE m.chamado_id = :id
          ORDER BY m.criado_em, m.id'
    );
    $stmt->execute([':id' => $id]);
    $comentarios = $stmt->fetchAll();
}

$fmt    = static fn (string $data): string => date('d/m/Y H:i', strtotime($data));
$titulo = $naoEncontrado ? 'Chamado não encontrado' : 'Chamado #' . $chamado['id'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($titulo) ?> · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topo">
    <a class="marca" href="chamados.php">Chamados · Concessionária</a>
    <nav>
        <a href="chamados.php">Chamados</a>
        <a href="novo_chamado.php">Novo chamado</a>
        <?php if ($usuario['perfil'] === 'admin'): ?>
            <a href="usuarios.php">Usuários</a>
        <?php endif; ?>
        <span class="nome"><?= e($usuario['nome']) ?></span>
        <a href="logout.php">Sair</a>
    </nav>
</header>

<main class="conteudo">
    <section class="cartao">
        <a class="voltar" href="chamados.php">&larr; Voltar à lista</a>

        <?php if ($naoEncontrado): ?>
            <h1>Chamado não encontrado</h1>
            <p>Esse chamado não existe ou você não tem acesso a ele.</p>
        <?php else: ?>

            <?php if ($flash): ?>
                <div class="alerta <?= e($flash['tipo']) ?>"><?= e($flash['mensagem']) ?></div>
            <?php endif; ?>

            <?php if ($erros): ?>
                <div class="alerta erro">
                    <ul>
                        <?php foreach ($erros as $erro): ?>
                            <li><?= e($erro) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <h1>#<?= (int) $chamado['id'] ?> · <?= e($chamado['titulo']) ?></h1>

            <dl class="detalhes">
                <div><dt>Solicitante</dt><dd><?= e($chamado['solicitante']) ?> (<?= e($chamado['setor']) ?>)</dd></div>
                <div><dt>Prioridade</dt><dd><span class="selo selo-<?= e($chamado['prioridade']) ?>"><?= e(rotulo($chamado['prioridade'])) ?></span></dd></div>
                <div><dt>Status</dt><dd><span class="status status-<?= e($chamado['status']) ?>"><?= e(rotulo($chamado['status'])) ?></span></dd></div>
                <div><dt>Aberto em</dt><dd><?= e($fmt($chamado['criado_em'])) ?></dd></div>
                <div><dt>Atualizado em</dt><dd><?= e($fmt($chamado['atualizado_em'])) ?></dd></div>
            </dl>

            <h2>Descrição</h2>
            <p class="texto-livre"><?= nl2br(e($chamado['descricao'])) ?></p>

            <?php if ($veTodos): ?>
                <form method="post" class="linha-form">
                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                    <input type="hidden" name="acao" value="status">
                    <label for="status">Alterar status</label>
                    <select id="status" name="status">
                        <?php foreach (STATUS_VALIDOS as $s): ?>
                            <option value="<?= e($s) ?>" <?= $s === $chamado['status'] ? 'selected' : '' ?>>
                                <?= e(rotulo($s)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Salvar</button>
                </form>
            <?php endif; ?>

            <h2>Comentários (<?= count($comentarios) ?>)</h2>

            <?php if (!$comentarios): ?>
                <p class="vazio">Nenhum comentário ainda.</p>
            <?php endif; ?>

            <?php foreach ($comentarios as $c): ?>
                <article class="comentario <?= $c['perfil'] !== 'solicitante' ? 'comentario-equipe' : '' ?>">
                    <header>
                        <strong><?= e($c['nome']) ?></strong>
                        <?php if ($c['perfil'] !== 'solicitante'): ?><span class="selo">Equipe</span><?php endif; ?>
                        <time><?= e($fmt($c['criado_em'])) ?></time>
                    </header>
                    <p><?= nl2br(e($c['mensagem'])) ?></p>
                </article>
            <?php endforeach; ?>

            <?php if ($chamado['status'] !== 'fechado'): ?>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                    <input type="hidden" name="acao" value="comentar">
                    <label for="mensagem">Novo comentário</label>
                    <textarea id="mensagem" name="mensagem" rows="4" maxlength="2000" required><?= e($mensagemDigitada) ?></textarea>
                    <button type="submit">Comentar</button>
                </form>
            <?php else: ?>
                <p class="vazio">Este chamado está fechado.</p>
            <?php endif; ?>

        <?php endif; ?>
    </section>
</main>
</body>
</html>