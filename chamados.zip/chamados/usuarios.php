<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

const PERFIS = ['solicitante', 'tecnico', 'admin'];

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

function rotulo(string $valor): string
{
    static $mapa = ['media' => 'Média', 'em_andamento' => 'Em andamento', 'tecnico' => 'Técnico'];
    return $mapa[$valor] ?? ucfirst($valor);
}

$usuario = $_SESSION['usuario'] ?? null;
if ($usuario === null) {
    header('Location: login.php');
    exit;
}
if ($usuario['perfil'] !== 'admin') {
    http_response_code(403);
    exit('Acesso negado.');
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$pdo   = db();
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $alvoId = filter_var($_POST['usuario_id'] ?? null, FILTER_VALIDATE_INT);
    $perfil = (string) ($_POST['perfil'] ?? '');
    $ativo  = isset($_POST['ativo']) ? 1 : 0;

    if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    } elseif (!$alvoId || $alvoId < 1) {
        $erros[] = 'Usuário inválido.';
    } elseif ($alvoId === (int) $usuario['id']) {
        // Evita que o único admin se bloqueie sem querer.
        $erros[] = 'Você não pode alterar o seu próprio perfil ou status.';
    } elseif (!in_array($perfil, PERFIS, true)) {
        $erros[] = 'Perfil inválido.';
    } else {
        $upd = $pdo->prepare('UPDATE usuarios SET perfil = :perfil, ativo = :ativo WHERE id = :id');
        $upd->execute([':perfil' => $perfil, ':ativo' => $ativo, ':id' => $alvoId]);

        $_SESSION['flash'] = ['tipo' => 'sucesso', 'mensagem' => 'Usuário atualizado.'];
        header('Location: usuarios.php');
        exit;
    }
}

$usuarios = $pdo->query(
    'SELECT u.id, u.nome, u.email, u.perfil, u.ativo, u.criado_em, s.nome AS setor
       FROM usuarios u
       JOIN setores s ON s.id = u.setor_id
      ORDER BY u.nome'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuários · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topo">
    <a class="marca" href="chamados.php">Chamados · Concessionária</a>
    <nav>
        <a href="chamados.php">Chamados</a>
        <a href="novo_chamado.php">Novo chamado</a>
        <a href="usuarios.php">Usuários</a>
        <span class="nome"><?= e($usuario['nome']) ?></span>
        <a href="logout.php">Sair</a>
    </nav>
</header>

<main class="conteudo">
    <section class="cartao">
        <h1>Usuários</h1>

        <?php if ($flash): ?>
            <div class="alerta <?= e($flash['tipo']) ?>"><?= e($flash['mensagem']) ?></div>
        <?php endif; ?>

        <?php if ($erros): ?>
            <div class="alerta erro">
                <ul>
                    <?php foreach ($erros as $erro): ?>
                        <li><?= e($erro) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="tabela-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Setor</th>
                        <th>Cadastro</th>
                        <th>Perfil e status</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($usuarios as $u): ?>
                    <?php $ehVoce = (int) $u['id'] === (int) $usuario['id']; ?>
                    <tr>
                        <td><?= e($u['nome']) ?><?= $ehVoce ? ' <em>(você)</em>' : '' ?></td>
                        <td><?= e($u['email']) ?></td>
                        <td><?= e($u['setor']) ?></td>
                        <td><?= e(date('d/m/Y', strtotime($u['criado_em']))) ?></td>
                        <td>
                            <form method="post" class="linha-form">
                                <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                                <input type="hidden" name="usuario_id" value="<?= (int) $u['id'] ?>">
                                <select name="perfil" aria-label="Perfil" <?= $ehVoce ? 'disabled' : '' ?>>
                                    <?php foreach (PERFIS as $p): ?>
                                        <option value="<?= e($p) ?>" <?= $p === $u['perfil'] ? 'selected' : '' ?>>
                                            <?= e(rotulo($p)) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <label class="check">
                                    <input type="checkbox" name="ativo" value="1"
                                        <?= $u['ativo'] ? 'checked' : '' ?> <?= $ehVoce ? 'disabled' : '' ?>>
                                    Ativo
                                </label>
                                <button type="submit" <?= $ehVoce ? 'disabled' : '' ?>>Salvar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
</body>
</html>