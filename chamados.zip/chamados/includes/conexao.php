<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_PORT = 3306;
const DB_NAME = 'chamados_concessionaria';
const DB_USER = 'app_chamados';
const DB_PASS = 'TROQUE_ESTA_SENHA';


function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            DB_HOST,
            DB_PORT,
            DB_NAME
        );

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
           
            error_log('Erro de conexão com o banco: ' . $e->getMessage());
            http_response_code(500);
            exit('Não foi possível conectar ao banco de dados. Tente novamente mais tarde.');
        }
    }

    return $pdo;
}