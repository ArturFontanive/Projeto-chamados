<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

function rotulo(string $valor): string
{
    static $mapa = ['media' => 'Média', 'em_andamento' => 'Em andamento', 'tecnico' => 'Técnico'];
    return $mapa[$valor] ?? ucfirst($valor);
}

$usuario = $_SESSION['usuario'] ?? null;
if ($usuario === null) {
    header('Location: login.php');
    exit;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Técnico e admin veem todos os chamados; solicitante vê só os seus.
$veTodos = in_array($usuario['perfil'], ['tecnico', 'admin'], true);

$sql = 'SELECT c.id, c.titulo, c.prioridade, c.status, c.criado_em, u.nome AS solicitante
          FROM chamados c
          JOIN usuarios u ON u.id = c.usuario_id';
$params = [];

if (!$veTodos) {
    $sql .= ' WHERE c.usuario_id = :uid';
    $params[':uid'] = (int) $usuario['id'];
}
$sql .= ' ORDER BY c.criado_em DESC LIMIT 100';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$chamados = $stmt->fetchAll();

$titulo = $veTodos ? 'Todos os chamados' : 'Meus chamados';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($titulo) ?> · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topo">
    <a class="marca" href="chamados.php">Chamados · Concessionária</a>
    <nav>
        <a href="chamados.php">Chamados</a>
        <a href="novo_chamado.php">Novo chamado</a>
        <?php if ($usuario['perfil'] === 'admin'): ?>
            <a href="usuarios.php">Usuários</a>
        <?php endif; ?>
        <span class="nome"><?= e($usuario['nome']) ?></span>
        <a href="logout.php">Sair</a>
    </nav>
</header>

<main class="conteudo">
    <section class="cartao">
        <h1><?= e($titulo) ?></h1>

        <?php if ($flash): ?>
            <div class="alerta <?= e($flash['tipo']) ?>"><?= e($flash['mensagem']) ?></div>
        <?php endif; ?>

        <?php if (!$chamados): ?>
            <p>Nenhum chamado encontrado. <a href="novo_chamado.php">Abrir um chamado</a></p>
        <?php else: ?>
            <div class="tabela-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Título</th>
                            <?php if ($veTodos): ?><th>Solicitante</th><?php endif; ?>
                            <th>Prioridade</th>
                            <th>Status</th>
                            <th>Aberto em</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($chamados as $c): ?>
                        <tr>
                            <td><?= (int) $c['id'] ?></td>
                            <td><a href="ver_chamado.php?id=<?= (int) $c['id'] ?>"><?= e($c['titulo']) ?></a></td>
                            <?php if ($veTodos): ?><td><?= e($c['solicitante']) ?></td><?php endif; ?>
                            <td><span class="selo selo-<?= e($c['prioridade']) ?>"><?= e(rotulo($c['prioridade'])) ?></span></td>
                            <td><span class="status status-<?= e($c['status']) ?>"><?= e(rotulo($c['status'])) ?></span></td>
                            <td><?= e(date('d/m/Y H:i', strtotime($c['criado_em']))) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>