<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

const PRIORIDADES = ['baixa', 'media', 'alta', 'urgente'];

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

function rotulo(string $valor): string
{
    static $mapa = ['media' => 'Média', 'em_andamento' => 'Em andamento', 'tecnico' => 'Técnico'];
    return $mapa[$valor] ?? ucfirst($valor);
}

$usuario = $_SESSION['usuario'] ?? null;
if ($usuario === null) {
    header('Location: login.php');
    exit;
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$pdo   = db();
$erros = [];
$dados = ['titulo' => '', 'descricao' => '', 'prioridade' => 'media'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    }

    $dados['titulo']     = trim((string) ($_POST['titulo'] ?? ''));
    $dados['descricao']  = trim((string) ($_POST['descricao'] ?? ''));
    $dados['prioridade'] = (string) ($_POST['prioridade'] ?? '');

    if (mb_strlen($dados['titulo']) < 5 || mb_strlen($dados['titulo']) > 150) {
        $erros[] = 'O título deve ter entre 5 e 150 caracteres.';
    }
    if (mb_strlen($dados['descricao']) < 10 || mb_strlen($dados['descricao']) > 5000) {
        $erros[] = 'A descrição deve ter entre 10 e 5000 caracteres.';
    }
    if (!in_array($dados['prioridade'], PRIORIDADES, true)) {
        $erros[] = 'Selecione uma prioridade válida.';
    }

    if (!$erros) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO chamados (usuario_id, titulo, descricao, prioridade)
                 VALUES (:usuario_id, :titulo, :descricao, :prioridade)'
            );
            $stmt->execute([
                ':usuario_id' => (int) $usuario['id'],
                ':titulo'     => $dados['titulo'],
                ':descricao'  => $dados['descricao'],
                ':prioridade' => $dados['prioridade'],
            ]);

            $_SESSION['flash'] = [
                'tipo'     => 'sucesso',
                'mensagem' => 'Chamado #' . $pdo->lastInsertId() . ' aberto com sucesso!',
            ];
            header('Location: chamados.php');
            exit;
        } catch (PDOException $e) {
            error_log('Erro ao abrir chamado: ' . $e->getMessage());
            $erros[] = 'Erro ao salvar o chamado. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Novo chamado · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topo">
    <a class="marca" href="chamados.php">Chamados · Concessionária</a>
    <nav>
        <a href="chamados.php">Chamados</a>
        <a href="novo_chamado.php">Novo chamado</a>
        <?php if ($usuario['perfil'] === 'admin'): ?>
            <a href="usuarios.php">Usuários</a>
        <?php endif; ?>
        <span class="nome"><?= e($usuario['nome']) ?></span>
        <a href="logout.php">Sair</a>
    </nav>
</header>

<main class="conteudo">
    <section class="cartao">
        <h1>Abrir chamado</h1>

        <?php if ($erros): ?>
            <div class="alerta erro">
                <ul>
                    <?php foreach ($erros as $erro): ?>
                        <li><?= e($erro) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">

            <label for="titulo">Título</label>
            <input type="text" id="titulo" name="titulo" maxlength="150" required value="<?= e($dados['titulo']) ?>">

            <label for="prioridade">Prioridade</label>
            <select id="prioridade" name="prioridade">
                <?php foreach (PRIORIDADES as $p): ?>
                    <option value="<?= e($p) ?>" <?= $p === $dados['prioridade'] ? 'selected' : '' ?>>
                        <?= e(rotulo($p)) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="descricao">Descrição do problema</label>
            <textarea id="descricao" name="descricao" rows="6" maxlength="5000" required><?= e($dados['descricao']) ?></textarea>

            <button type="submit">Enviar chamado</button>
        </form>
    </section>
</main>
</body>
</html>