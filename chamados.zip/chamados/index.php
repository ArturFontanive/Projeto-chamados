<?php
declare(strict_types=1);
ini_set('display_errors', '1');
error_reporting(E_ALL);


session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

$usuario = $_SESSION['usuario'] ?? null;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Central de chamados internos da concessionária: abra solicitações e acompanhe o andamento em tempo real.">
    <title>Central de Chamados · Concessionária</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="topo">
    <a class="marca" href="index.php">Chamados · Concessionária</a>
    <nav>
        <?php if ($usuario): ?>
            <a href="chamados.php">Chamados</a>
            <span class="nome"><?= e($usuario['nome']) ?></span>
            <a href="logout.php">Sair</a>
        <?php else: ?>
            <a href="login.php">Entrar</a>
            <a href="cadastro.php">Cadastrar</a>
        <?php endif; ?>
    </nav>
</header>

<section class="hero">
    <div class="hero-conteudo">
        <h1>Central de Chamados</h1>
        <p>
            Precisa de ajuda de outro setor? Abra um chamado, acompanhe o andamento
            e converse com a equipe responsável, tudo em um só lugar.
        </p>
        <div class="hero-acoes">
            <?php if ($usuario): ?>
                <a class="btn btn-primario" href="novo_chamado.php">Abrir um chamado</a>
                <a class="btn btn-contorno" href="chamados.php">Ir para os chamados</a>
            <?php else: ?>
                <a class="btn btn-primario" href="login.php">Entrar</a>
                <a class="btn btn-contorno" href="cadastro.php">Criar conta</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="secao">
    <h2>Como funciona</h2>
    <p class="secao-sub">Três passos para resolver qualquer solicitação interna.</p>

    <div class="grade">
        <article class="item">
            <span class="passo-num">1</span>
            <h3>Crie sua conta</h3>
            <p>Cadastre-se com seu e-mail e escolha o setor em que você trabalha.</p>
        </article>
        <article class="item">
            <span class="passo-num">2</span>
            <h3>Abra um chamado</h3>
            <p>Descreva o problema e defina a prioridade: baixa, média, alta ou urgente.</p>
        </article>
        <article class="item">
            <span class="passo-num">3</span>
            <h3>Acompanhe</h3>
            <p>Veja o status do chamado e troque mensagens com a equipe até a solução.</p>
        </article>
    </div>
</section>

<section class="secao secao-alt">
    <div>
        <h2>O que você encontra aqui</h2>
        <p class="secao-sub">Um controle simples para nenhuma solicitação ficar perdida.</p>

        <div class="grade">
            <article class="item">
                <h3>Histórico completo</h3>
                <p>Todos os seus chamados ficam registrados, com data, prioridade e situação.</p>
            </article>
            <article class="item">
                <h3>Status em tempo real</h3>
                <p>Aberto, em andamento, resolvido ou fechado: você sabe em que etapa está.</p>
            </article>
            <article class="item">
                <h3>Conversa no chamado</h3>
                <p>Comentários direto na solicitação, sem depender de mensagens soltas.</p>
            </article>
            <article class="item">
                <h3>Acesso protegido</h3>
                <p>Cada pessoa vê apenas os próprios chamados. A equipe técnica vê todos.</p>
            </article>
        </div>
    </div>
</section>

<section class="secao">
    <h2>Setores atendidos</h2>
    <p class="secao-sub">Escolha o seu setor ao se cadastrar.</p>

    <ul class="setores">
        <li>Vendas</li>
        <li>Pós-vendas</li>
        <li>Oficina</li>
        <li>Peças</li>
        <li>Financeiro</li>
        <li>Administrativo</li>
        <li>TI</li>
    </ul>
</section>

<footer class="rodape-site">
    &copy; <?= date('Y') ?> Concessionária · Central de Chamados
</footer>

</body>
</html>