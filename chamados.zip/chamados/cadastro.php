<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

if (isset($_SESSION['usuario'])) {
    header('Location: chamados.php');
    exit;
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$pdo = db();
$setores = $pdo->query('SELECT id, nome FROM setores ORDER BY nome')->fetchAll();
$idsSetores = array_map('intval', array_column($setores, 'id'));

$erros = [];
$dados = ['nome' => '', 'email' => '', 'setor_id' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $erros[] = 'Sessão expirada. Recarregue a página e tente novamente.';
    }

    $dados['nome']     = trim((string) ($_POST['nome'] ?? ''));
    $dados['email']    = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
    $dados['setor_id'] = (string) ($_POST['setor_id'] ?? '');
    $senha             = (string) ($_POST['senha'] ?? '');
    $confirmar         = (string) ($_POST['confirmar_senha'] ?? '');

    if (mb_strlen($dados['nome']) < 3 || mb_strlen($dados['nome']) > 120) {
        $erros[] = 'Informe o nome completo (3 a 120 caracteres).';
    }
    if (!filter_var($dados['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($dados['email']) > 160) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (!in_array((int) $dados['setor_id'], $idsSetores, true)) {
        $erros[] = 'Selecione um setor válido.';
    }
    if (strlen($senha) < 8) {
        $erros[] = 'A senha deve ter pelo menos 8 caracteres.';
    }
    if ($senha !== $confirmar) {
        $erros[] = 'A confirmação de senha não confere.';
    }

    if (!$erros) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO usuarios (nome, email, senha_hash, setor_id)
                 VALUES (:nome, :email, :senha_hash, :setor_id)'
            );
            $stmt->execute([
                ':nome'       => $dados['nome'],
                ':email'      => $dados['email'],
                ':senha_hash' => password_hash($senha, PASSWORD_DEFAULT),
                ':setor_id'   => (int) $dados['setor_id'],
            ]);

            $_SESSION['flash'] = ['tipo' => 'sucesso', 'mensagem' => 'Cadastro realizado! Faça login para continuar.'];
            header('Location: login.php');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') { // e-mail já existe (índice único)
                $erros[] = 'Este e-mail já está cadastrado.';
            } else {
                error_log('Erro no cadastro: ' . $e->getMessage());
                $erros[] = 'Erro ao salvar o cadastro. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="cartao">
    <h1>Criar conta</h1>

    <?php if ($erros): ?>
        <div class="alerta erro">
            <ul>
                <?php foreach ($erros as $erro): ?>
                    <li><?= e($erro) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">

        <label for="nome">Nome completo</label>
        <input type="text" id="nome" name="nome" maxlength="120" required value="<?= e($dados['nome']) ?>">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" maxlength="160" required value="<?= e($dados['email']) ?>">

        <label for="setor_id">Setor</label>
        <select id="setor_id" name="setor_id" required>
            <option value="">Selecione...</option>
            <?php foreach ($setores as $setor): ?>
                <option value="<?= (int) $setor['id'] ?>"
                    <?= (string) $setor['id'] === $dados['setor_id'] ? 'selected' : '' ?>>
                    <?= e($setor['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="senha">Senha (mínimo 8 caracteres)</label>
        <input type="password" id="senha" name="senha" minlength="8" required autocomplete="new-password">

        <label for="confirmar_senha">Confirmar senha</label>
        <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="8" required autocomplete="new-password">

        <button type="submit">Cadastrar</button>
        <p class="rodape-form">Já tem conta? <a href="login.php">Entrar</a></p>
    </form>
</section>
</body>
</html>