<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/conexao.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

if (isset($_SESSION['usuario'])) {
    header('Location: chamados.php');
    exit;
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$erro  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
    $senha = (string) ($_POST['senha'] ?? '');

    if (!hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $erro = 'Sessão expirada. Recarregue a página e tente novamente.';
    } else {
        $stmt = db()->prepare(
            'SELECT id, nome, email, senha_hash, perfil, setor_id
               FROM usuarios
              WHERE email = :email AND ativo = 1
              LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
            session_regenerate_id(true); // evita session fixation
            $_SESSION['usuario'] = [
                'id'       => (int) $usuario['id'],
                'nome'     => $usuario['nome'],
                'email'    => $usuario['email'],
                'perfil'   => $usuario['perfil'],
                'setor_id' => (int) $usuario['setor_id'],
            ];
            header('Location: chamados.php');
            exit;
        }

        // Mensagem genérica: não revela se o e-mail existe.
        $erro = 'E-mail ou senha inválidos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Entrar · Chamados</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="cartao">
    <h1>Entrar</h1>

    <?php if ($flash): ?>
        <div class="alerta <?= e($flash['tipo']) ?>"><?= e($flash['mensagem']) ?></div>
    <?php endif; ?>

    <?php if ($erro): ?>
        <div class="alerta erro"><?= e($erro) ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" required value="<?= e($email) ?>">

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required autocomplete="current-password">

        <button type="submit">Entrar</button>
        <p class="rodape-form">Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
    </form>
</section>
</body>
</html>